//******************************************************
//Instituto Federal de São Paulo - Campus Sertãozinho
//Disciplina......: M3LPBD
//Programação de Computadores e Dispositivos Móveis
//Aluno...........: Andre Luiz Resende Pacheco Da Silva
//******************************************************

package cadastrodisciplina;

/**
 *
 * @author Andre
 */
public class CadastroDisciplina {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
